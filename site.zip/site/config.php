<?php
    $dbHost = 'localhost';
    $dbUsername = 'root';
    $dbPassword = '';
    $dbName = 'viagens';

    $conexao = new mysqli($dbHost,$dbUsername,$dbPassword,$dbName);
?>