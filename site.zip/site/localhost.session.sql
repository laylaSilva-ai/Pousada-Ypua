use viagens;

select * from boletos;